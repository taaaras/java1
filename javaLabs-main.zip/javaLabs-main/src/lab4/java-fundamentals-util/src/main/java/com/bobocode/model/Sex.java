package com.bobocode.model;

public enum Sex {
    MALE,
    FEMALE
}
