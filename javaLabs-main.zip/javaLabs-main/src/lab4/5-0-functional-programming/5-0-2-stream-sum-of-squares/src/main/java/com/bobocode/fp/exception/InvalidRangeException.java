package com.bobocode.fp.exception;

public class InvalidRangeException extends RuntimeException {
}
