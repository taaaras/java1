package src.lab2;

public abstract class Shape {
  public abstract double getArea();
}
