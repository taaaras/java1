package src.lab6;

public class Light {
  void turnOn() {
    System.out.println("The light is on");
  }

  void turnOff() {
    System.out.println("The light is off");
  }
}