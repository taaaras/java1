package src.lab6;

interface Command {
  void execute();
}
